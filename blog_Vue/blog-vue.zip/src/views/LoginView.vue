<template>
    <div class="flex justify-center">
      <LoginComponent/>
    </div>
    </template>
    
    <script setup>
    import LoginComponent from '../components/LoginComponent.vue';
    </script>