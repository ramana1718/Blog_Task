<template>
    <h1>This is the settings page</h1>
</template>