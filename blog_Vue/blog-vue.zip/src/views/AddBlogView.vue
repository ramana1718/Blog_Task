<template>
    <div class="flex  justify-center ">
        <FormComponent/>
    </div>

</template>
<script setup>
import FormComponent from '@/components/FormComponent.vue';
</script>