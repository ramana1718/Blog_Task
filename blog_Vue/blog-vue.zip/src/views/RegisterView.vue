<template>
    <div>
        <RegisterComponent  />
    </div>

</template>
<script setup>
import RegisterComponent from '@/components/RegisterComponent.vue';
</script>